import os
import requests
import json
from openai import OpenAI
client = OpenAI()


def scrape_search_results(query):
    url = "https://google.serper.dev/search"

    payload = json.dumps({
        "q": query,
        "hl": "en",
        "gl": "us",
        "google_domain": "google.com",
        "num": 10,
        "page":1,
        "tbs": "qdr:d"
    })
    headers = {
        'X-API-KEY': 'bc0880ee3fd12fb3fc902ec22ec2310658de3d45',
        'Content-Type': 'application/json'
    }
    
    response = requests.request("POST", url, headers=headers, data=payload)
    data = json.loads(response.text)

    # Extract the snippets
    return [result["snippet"] for result in data.get("organic", []) if "snippet" in result]




def synthesize_paragraph(query, key_points):
    """
    Create a coherent paragraph from the generated key points using the OpenAI API.
    """
    client = OpenAI()
    key_points_text = "\n".join(key_points)
    prompt = f"Create a podcast script based on the query '{query}' and the following key points. The script should be engaging, easy to follow, and structured with an introduction, body, and conclusion. It should be suitable for a 5-minute podcast, approximately 500 words, the final generated text should only include the words that the host will say, and start every podcast with 'Welcome back to your bites infocast'. Key points:\n{key_points_text}"
    if len(prompt) > 4000:
        prompt = prompt[:4000]
    try:
        completion = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an assistant who summarizes articles."},
                {"role": "user", "content": prompt}
            ]
        )
        script = completion.choices[0].message.content
        return script
    except Exception as e:
        print(f"Error generating key points: {e}")
        return ""


def main(query):
    key_points = scrape_search_results(query)

    if key_points:
        final_paragraph = synthesize_paragraph(query, key_points)
        # print("Final synthesized podcast script:")
        # print(final_paragraph)
        return final_paragraph
    else:
        print("No key points generated.")


if __name__ == "__main__":
    query = "Tell me about the recent updates in technology"
    text = main(query)
    print(text)
    client = OpenAI()
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text,
    )
    response.stream_to_file("output.mp3")

    #key sk-jWS7CO_EqVIfCKv5lPvR3FqwBr0YwNmC03afDaPtUCT3BlbkFJCsAzybpzjZjeFVrZbSGiXKfjJ1c2napikjwgSEY3wA
